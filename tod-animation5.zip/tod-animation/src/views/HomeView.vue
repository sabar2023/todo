<script setup></script>

<template>
  <main>
    <transition name="fade">
      <h1>Hello world</h1>
    </transition>
  </main>
</template>
