<template>
  <div class="about">
    <h1>This is an about page</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Deleniti quos iste, quaerat nemo doloribus unde beatae, vero odio, dolor ipsum maxime totam quidem nostrum consequuntur voluptate aliquam doloremque blanditiis temporibus.</p>
  </div>
</template>

<style>
.about {
  max-width: 300px;
  margin: 0 auto;
}
</style>
